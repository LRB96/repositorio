# -*- coding: utf-8 -*-
"""
@author: Octavio Gutiérrez de Código Máquina

URL del canal: https://www.youtube.com/CodigoMaquina

URL del video: https://youtu.be/bf_698bfPDU

"""

#import math as m

#from math import *

#print(floor(2.5),ceil(2.5))

from manejo_archivos import leer, escribir

escribir("archivo.txt", "Un texto")
print(leer("archivo.txt"))

