# -*- coding: utf-8 -*-
"""
@author: Octavio Gutiérrez de Código Máquina

URL del canal: https://www.youtube.com/CodigoMaquina

URL del video: https://youtu.be/wxBrLA9pOas

"""


externa = "EXTERNA"

def funcion(parametro):
    interna = "INTERNA"
    print ("Adentro", externa, parametro, interna)

funcion("PARAMETRO")

print("Afuera", externa)
    





    