# -*- coding: utf-8 -*-
"""
@author: Octavio Gutiérrez de Código Máquina

URL del canal: https://www.youtube.com/CodigoMaquina

URL del video: https://youtu.be/RC4QkyWthbI

"""

edad = 25 
altura = 1.73
print(edad, altura)
print(type(edad), type(altura))

a = 5
b = 2 

print(a + b)
print(a - b)
print(a * b)
print(a / b)
print(a // b)
print(a % b)
print(-a)
print(a**b)
print(a + a*b)
print((a+b) * a)

nombre = "Octavio"
apellido = "Gutierrez"
nombre_completo = nombre + " " + apellido

print(nombre_completo)
print("Longitud", len(nombre_completo))
print("Multiplicación", nombre_completo*3)

tres = str(3)
decimal = str(3.14)

tres_entera = int(tres)
tres_decimal = float(decimal)

print(0, nombre[0])
print(1, nombre[1])
print(2, nombre[2])
print(3, nombre[3])
print(4, nombre[4])
print(5, nombre[5])

print(nombre[len(nombre)-1])

adulto = True
print(adulto)

