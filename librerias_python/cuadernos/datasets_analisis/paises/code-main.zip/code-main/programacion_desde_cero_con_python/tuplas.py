# -*- coding: utf-8 -*-
"""
@author: Octavio Gutiérrez de Código Máquina

URL del canal: https://www.youtube.com/CodigoMaquina

URL del video: https://youtu.be/9hDL2gZqYJs
"""

tupla = ("Juan", 22)
print(tupla[0])
lista = list(tupla)
lista[0] = "Juana"
una_tupla = tuple(lista)
print(una_tupla)
conjunto = set (una_tupla)
print(conjunto)