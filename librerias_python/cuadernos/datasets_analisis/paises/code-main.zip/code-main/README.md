- 👋 En @CodigoMaquina nuestra misión es compartir conocimientos sobre:
    
    - 👀 Programación, 
    
    - 👀 Inteligencia Artificial y
        
    - 👀 Aprendizaje de Máquina.

Aquí se encuentra todo el código explicado en el canal de YouTube Código Máquina https://www.youtube.com/c/CodigoMaquina/

Todo el código del repositorio está organizado en función de las playlists del canal https://www.youtube.com/c/CodigoMaquina/playlists
